/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author leona
 */
public class Comedor extends SetTerraza {

    private double anchoMesa;
    private double altoMesa;
    private int capacidad;

    public Comedor(int id, String nombre, String material,
                   double anchoMesa, double altoMesa, int capacidad) {
        super(id, nombre, material, "Comedor (Mesa Grande)");
        this.anchoMesa = anchoMesa;
        this.altoMesa = altoMesa;
        this.capacidad = capacidad;
    }

    @Override
    public String getDetalle() {
        return "Mesa: " + anchoMesa + " x " + altoMesa +
               " m, Capacidad: " + capacidad + " personas";
    }
}