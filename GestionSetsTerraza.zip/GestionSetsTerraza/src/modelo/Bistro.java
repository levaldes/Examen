package modelo;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author leona
 */
public class Bistro extends SetTerraza {

    private double diametro;

    public Bistro(int id, String nombre, String material, double diametro) {
        super(id, nombre, material, "Bistro (Mesa Pequeña)");
        this.diametro = diametro;
    }

    @Override
    public String getDetalle() {
        return "Diámetro mesa: " + diametro + " m";
    }
}