/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author leona
 */
public class Living extends SetTerraza {

    private int numSofas;
    private boolean cojines;

    public Living(int id, String nombre, String material,
                  int numSofas, boolean cojines) {
        super(id, nombre, material, "Living (Sofás)");
        this.numSofas = numSofas;
        this.cojines = cojines;
    }

    @Override
    public String getDetalle() {
        return "Sofás: " + numSofas + ", Cojines: " + (cojines ? "Sí" : "No");
    }
}