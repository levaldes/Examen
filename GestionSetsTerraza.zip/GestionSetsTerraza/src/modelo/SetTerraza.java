/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author leona
 */
public abstract class SetTerraza {

    protected int id;
    protected String nombre;
    protected String material;
    protected String tipo;

    public SetTerraza(int id, String nombre, String material, String tipo) {
        this.id = id;
        this.nombre = nombre;
        this.material = material;
        this.tipo = tipo;
    }
    
    public String getNombre() {
    return nombre;
    }

    public String getMaterial() {
    return material;
    }

    public String getTipo() {
    return tipo;
    }

    public int getId() {
        return id;
    }

    public abstract String getDetalle();
}