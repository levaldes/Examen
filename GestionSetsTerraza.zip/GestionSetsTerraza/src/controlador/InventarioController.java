/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

/**
 *
 * @author leona
 */
import modelo.SetTerraza;
import java.util.ArrayList;

public class InventarioController {

    private ArrayList<SetTerraza> inventario;

    public InventarioController() {
        inventario = new ArrayList<>();
    }

    public void agregar(SetTerraza set) {
        inventario.add(set);
    }

    public boolean eliminarPorId(int id) {
        return inventario.removeIf(s -> s.getId() == id);
    }

    public ArrayList<SetTerraza> listar() {
        return inventario;
    }
}